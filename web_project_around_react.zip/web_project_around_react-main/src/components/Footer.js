function Footer() {
  return (
    <>
      <footer className='footer'>
        <p className='footer__firma'>© 2024 Berenice Aparicio Zúñiga</p>
      </footer>
    </>
  );
}

export default Footer;
